const express = require('express');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.static('public'));

const PORT = process.env.PORT || 3000;

app.post('/api/roast', async (req, res) => {
  const { username, style } = req.body;

  if (!username) {
    return res.status(400).json({ error: 'Username is required' });
  }

  // Fetch GitHub user + repos
  let userData, repos;
  try {
    const headers = { 'User-Agent': 'roast-my-github-app' };
    if (process.env.GITHUB_TOKEN) {
      headers['Authorization'] = `token ${process.env.GITHUB_TOKEN}`;
    }

    const userRes = await fetch(`https://api.github.com/users/${username}`, { headers });
    if (userRes.status === 404) {
      return res.status(404).json({ error: `User "${username}" not found on GitHub.` });
    }
    if (!userRes.ok) {
      return res.status(502).json({ error: 'GitHub API is being moody. Try again in a bit.' });
    }
    userData = await userRes.json();

    const repoRes = await fetch(
      `https://api.github.com/users/${username}/repos?per_page=30&sort=updated`,
      { headers }
    );
    repos = await repoRes.json();
  } catch (err) {
    return res.status(502).json({ error: 'Could not reach GitHub. Check your connection.' });
  }

  if (!repos.length) {
    return res.status(400).json({ error: `${username} has no public repos. Nothing to roast.` });
  }

  // Build a summary of the developer's profile
  const repoSummary = repos.slice(0, 20).map(r =>
    `- ${r.name} (${r.language || 'mystery language'}, ${r.stargazers_count} ⭐, last updated ${r.updated_at?.slice(0, 10)}): ${r.description || 'no description'}`
  ).join('\n');

  const profile = [
    `Username: ${userData.login}`,
    `Bio: ${userData.bio || 'none'}`,
    `Followers: ${userData.followers}, Following: ${userData.following}`,
    `Public repos: ${userData.public_repos}`,
    `Account created: ${userData.created_at?.slice(0, 10)}`,
    `Company: ${userData.company || 'none'}`,
  ].join('\n');

  const styleInstructions = {
    default: 'Be funny, sharp, and a little brutal — like a roast from a fellow developer who actually cares. Reference specific repos by name.',
    corporate: 'Roast them using insufferable corporate jargon — synergies, KPIs, pivot to value, thought leadership. The more buzzwords the better.',
    pirate: 'Roast them as a pirate would. Use seafaring metaphors, "arr"s, and compare their commits to sinking ships.',
    haiku: 'Deliver the entire roast exclusively in haikus (5-7-5 syllables). Each haiku should roast a different aspect of their profile.',
    shakespeare: 'Roast them in the style of Shakespeare — iambic pentameter encouraged, dramatic insults, thee/thou/thy.',
  };

  const prompt = `You are a witty developer who has been asked to roast a GitHub user based on their public profile. 
This is a friendly roast — think Comedy Central roast energy, not actual meanness.

Here's their profile:
${profile}

Their repos:
${repoSummary}

Style instructions: ${styleInstructions[style] || styleInstructions.default}

Write a roast that is 3-5 paragraphs. Be specific — mention actual repo names, languages, or patterns you notice. 
Keep it fun and the kind of thing a developer would laugh at and share. No need to soften it too much.`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-opus-4-5',
        max_tokens: 1024,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    if (!response.ok) {
      const err = await response.json();
      console.error('Anthropic error:', err);
      return res.status(502).json({ error: 'AI roast generator failed. Even the AI is embarrassed.' });
    }

    const data = await response.json();
    const roast = data.content[0].text;

    res.json({
      roast,
      username: userData.login,
      avatar: userData.avatar_url,
      name: userData.name || userData.login,
      repoCount: userData.public_repos,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Something broke on our end. Ironic, given we\'re roasting coders.' });
  }
});

app.listen(PORT, () => {
  console.log(`Roast server running on http://localhost:${PORT}`);
});
