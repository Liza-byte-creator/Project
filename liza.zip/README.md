# 🔥 Roast My GitHub

Enter a GitHub username, get a developer-roast generated from their actual public repos. Five roast styles: classic, corporate jargon, pirate, haiku, and Shakespeare.

## Running it

```bash
cp .env.example .env
# Add your ANTHROPIC_API_KEY to .env
npm install
npm start
# Open http://localhost:3000
```

On Replit: add `ANTHROPIC_API_KEY` to the Secrets panel, then hit Run.

## What it does

1. Hits `GET /users/{username}` and `/users/{username}/repos` on GitHub's public API
2. Summarises the profile (languages, repo names, last activity, bio) and builds a prompt
3. Claude generates a 3–5 paragraph roast, referencing actual repos by name
4. Handles 404s (user doesn't exist), empty profiles (no public repos), and GitHub API failures with useful messages — not crashes

## The prompt I landed on

After a few tries I settled on giving Claude a structured profile dump rather than asking it to "imagine" the user. Concrete data — repo names, update dates, star counts — makes the roast land better because it references real things. I tried a single-shot "roast this username" prompt first; the output was generic and boring because Claude had no actual data to work with.

The style instructions are injected per-style. The haiku mode was the most finicky to get right — had to tell Claude "each haiku must roast a DIFFERENT aspect" or it'd write variations on the same joke.

## What I'd add with more time

- Syntax-highlight the roast output with repo names bolded
- Cache results by username + style for 30 minutes so repeat lookups don't burn API quota
- Add GitHub OAuth so it can also roast private repo metadata (not content, just names/sizes)
- A "share your roast" button that generates a card image via Canvas API
