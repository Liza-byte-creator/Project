# 🤫 Standup Whisperer

Slack-style UI where you dump your messy dev notes and get back a clean standup (Yesterday / Today / Blockers). One button copies it ready to paste into Slack.

## Running it

```bash
cp .env.example .env
# Add ANTHROPIC_API_KEY to .env
npm install
npm start
# Open http://localhost:3000
```

On Replit: add `ANTHROPIC_API_KEY` to Secrets.  
Keyboard shortcut: Cmd+Enter (Mac) / Ctrl+Enter (Windows) to send.

## What it does

You paste notes like:

> "fixed the auth bug from yesterday, deploy pipeline kept failing on staging need to look at it, blocked on design review for dashboard"

And get back:

> **Yesterday**
> - Fixed authentication bug
>
> **Today**  
> - Investigate staging deploy pipeline failures
>
> **Blockers**
> - Waiting on design review for dashboard

Copy-to-Slack button copies the raw markdown — Slack renders `**bold**` and `- bullets` natively, so the formatting carries through.

## The prompt I settled on

The system prompt uses a strict output schema: "always use EXACTLY this structure". First version I tried was asking Claude to "write a standup", which produced good-looking text but inconsistent formatting — sometimes it added "Hey team!" headers, sometimes it added sign-offs. Not scriptable.

The final prompt also explicitly says "Do NOT add things not in the notes" because an early version was inventing blockers that didn't exist in the input. The safeguard `"If notes are truly empty or gibberish, return ERROR:"` was added after I tested with a single period — without it, Claude generates a creative standup about punctuation.

### What I tried first

First attempt used the user message alone with no system prompt, pasting prompt and notes together. It worked but was inconsistent. Moving the instructions to the system role made outputs much more predictable across chaotic inputs.

## What I'd add with more time

- Persist history in localStorage so you can see previous standups
- Let you set a team/project context in settings so Claude knows which project tickets belong to
- Add a "suggest emoji reactions" feature for the Slack post (half joke, half actually useful)
- Keyboard shortcut to pick up "notes from yesterday's standup" as context
