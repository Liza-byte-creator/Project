const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static('public'));

const SYSTEM_PROMPT = `You are a standup formatter. Your job is to turn messy developer notes into a clean async standup post.

Output format — always use EXACTLY this structure with these headers:
**Yesterday**
- bullet points of what was done

**Today**  
- bullet points of what will be done

**Blockers**
- bullet points of blockers, OR write "None" if there are none

Rules:
- Infer what belongs in each section from context — if something is clearly done, it's "Yesterday"; planned work is "Today"
- Keep each bullet concise but specific — don't strip out technical detail
- If a note mentions a ticket/PR number, keep it
- Do NOT add things that weren't in the notes — don't invent blockers or tasks
- If the notes are truly empty or gibberish, return exactly: ERROR: Notes are too sparse to generate a standup.
- Respond with ONLY the standup content. No preamble, no "here is your standup", no sign-off.`;

app.post('/api/standup', async (req, res) => {
  const { notes, name } = req.body;

  if (!notes || notes.trim().length < 10) {
    return res.status(400).json({ error: 'Notes are too short. Give me something to work with.' });
  }

  const userMessage = name
    ? `Developer: ${name}\n\nNotes:\n${notes}`
    : `Notes:\n${notes}`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-opus-4-5',
        max_tokens: 800,
        system: SYSTEM_PROMPT,
        messages: [{ role: 'user', content: userMessage }],
      }),
    });

    if (!response.ok) {
      const err = await response.json();
      console.error('Anthropic error:', err);
      return res.status(502).json({ error: 'AI formatter failed. Try again.' });
    }

    const data = await response.json();
    const standup = data.content[0].text.trim();

    if (standup.startsWith('ERROR:')) {
      return res.status(422).json({ error: standup.replace('ERROR: ', '') });
    }

    res.json({ standup });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error.' });
  }
});

app.listen(PORT, () => {
  console.log(`Standup Whisperer running on http://localhost:${PORT}`);
});
