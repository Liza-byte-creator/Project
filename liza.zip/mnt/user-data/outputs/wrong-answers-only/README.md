# 🚫 Wrong Answers Only

A quiz game where every single answer option is wrong. You pick one, it tells you why it's wrong — but they're all wrong, that's the joke. Score tracks how many you've picked (wrong), with a streak counter.

## Running it

```bash
cp .env.example .env
# Add ANTHROPIC_API_KEY to .env
npm install
npm start
# Open http://localhost:3000
```

On Replit: add `ANTHROPIC_API_KEY` to Secrets.

## What it does

1. Pick any topic (or tap a quick-topic button)
2. Claude generates a real question about that topic and four wrong-but-plausible answers
3. You pick one, see why it's wrong — but all four are wrong, so there's no "winning"
4. Streak and score tracked in memory during the session

## The prompt that enforces all-wrong answers

This was the most important thing to get right. Early versions would occasionally sneak in a correct answer, which breaks the whole concept. The key was being explicit twice:

- "ALL four choices are wrong"
- "NONE of the answers can be correct. Not even accidentally."

Also had to add "make them sound plausible — not obviously silly" because without it, Claude would generate clearly nonsense answers (like "The sun is made of cheese") which aren't funny. The humor only works when the wrong answer sounds *almost* right.

The explanations must be under 20 words and "a little snarky" — longer explanations killed the pace of the game.

### What I tried first

First attempt had Claude choose the topic itself randomly. Scrapped it — letting users pick topics is much more engaging and makes results personal/funny. (Someone asking about their own tech stack gets funnier wrong answers than a random topic.)

### Prompt I settled on

```
You are a quiz writer for a game called "Wrong Answers Only". The game has no correct answers — ALL four choices are wrong. That is the joke.

Generate a question about this topic and exactly four wrong-but-plausible answers...
```

(Full prompt is in server.js)

## What I'd add with more time

- Persist streak to localStorage (already has the structure for it)
- Add a "categories" mode where it gives you 5 questions on one topic in a row
- Leaderboard using a lightweight KV store (Replit has one built in)
- A "hardest" difficulty where the wrong answers are even more convincing
