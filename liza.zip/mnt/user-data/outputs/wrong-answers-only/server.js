const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static('public'));

app.post('/api/question', async (req, res) => {
  const { topic } = req.body;

  if (!topic || topic.trim().length < 2) {
    return res.status(400).json({ error: 'Pick a topic first.' });
  }

  const prompt = `You are a quiz writer for a game called "Wrong Answers Only". The game has no correct answers — ALL four choices are wrong. That is the joke.

Topic: ${topic.trim()}

Generate a question about this topic and exactly four wrong-but-plausible answers. Every single answer must be factually incorrect. The more confidently wrong the better.

Respond ONLY with a valid JSON object, no extra text:
{
  "question": "the question text",
  "answers": [
    { "text": "wrong answer 1", "explanation": "witty one-liner explaining why this is wrong" },
    { "text": "wrong answer 2", "explanation": "witty one-liner explaining why this is wrong" },
    { "text": "wrong answer 3", "explanation": "witty one-liner explaining why this is wrong" },
    { "text": "wrong answer 4", "explanation": "witty one-liner explaining why this is wrong" }
  ]
}

Critical rules:
- NONE of the answers can be correct. Not even accidentally.
- The question should be a real question with a real answer, but don't include that real answer anywhere in the output.
- Make the wrong answers sound plausible — not obviously silly — so it's funny when revealed they're wrong.
- Explanations should be short (under 20 words), punchy, and a little snarky.
- No markdown, no code fences, just the JSON.`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-opus-4-5',
        max_tokens: 800,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    if (!response.ok) {
      return res.status(502).json({ error: 'Failed to generate question.' });
    }

    const data = await response.json();
    const rawText = data.content[0].text.trim()
      .replace(/^```(?:json)?\n?/, '')
      .replace(/\n?```$/, '');

    let parsed;
    try {
      parsed = JSON.parse(rawText);
    } catch {
      return res.status(422).json({ error: 'Could not parse response. Try again.' });
    }

    // Shuffle answers
    parsed.answers = parsed.answers.sort(() => Math.random() - 0.5);

    res.json(parsed);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error.' });
  }
});

app.listen(PORT, () => {
  console.log(`Wrong Answers Only running on http://localhost:${PORT}`);
});
