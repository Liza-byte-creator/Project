const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// Store uploads in memory, not disk
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    if (allowed.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Only JPEG, PNG, WEBP, and GIF images are accepted.'));
    }
  },
});

app.use(express.static('public'));

app.post('/api/scan', upload.single('receipt'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No image uploaded.' });
  }

  const imageBase64 = req.file.buffer.toString('base64');
  const mediaType = req.file.mimetype;

  const prompt = `You are a receipt OCR assistant. Extract all data from this receipt image and return it as a single JSON object with NO additional text, no markdown, no explanation.

The JSON must follow this exact structure:
{
  "vendor": "store name or merchant name",
  "date": "date in YYYY-MM-DD format, or null if not visible",
  "currency": "ISO 4217 currency code (e.g. USD, EUR, GBP) — infer from symbols if needed",
  "items": [
    { "name": "item description", "qty": 1, "unit_price": 0.00, "total": 0.00 }
  ],
  "subtotal": 0.00,
  "tax": 0.00,
  "discount": 0.00,
  "total": 0.00,
  "payment_method": "cash / card / unknown"
}

Rules:
- If a field is not visible, use null for strings and 0 for numbers
- All monetary values must be numbers (not strings)
- qty must be a number
- If the image is not a receipt or is completely unreadable, return: { "error": "brief description of the problem" }
- Do not include any text outside the JSON object`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-opus-4-5',
        max_tokens: 1500,
        messages: [{
          role: 'user',
          content: [
            {
              type: 'image',
              source: { type: 'base64', media_type: mediaType, data: imageBase64 },
            },
            { type: 'text', text: prompt },
          ],
        }],
      }),
    });

    if (!response.ok) {
      const err = await response.json();
      console.error('Anthropic error:', err);
      return res.status(502).json({ error: 'Vision model failed to process the image.' });
    }

    const data = await response.json();
    const rawText = data.content[0].text.trim();

    // Strip markdown code fences if Claude added them despite instructions
    const cleaned = rawText.replace(/^```(?:json)?\n?/, '').replace(/\n?```$/, '').trim();

    let parsed;
    try {
      parsed = JSON.parse(cleaned);
    } catch {
      return res.status(422).json({
        error: 'Could not parse receipt data. The image may be too blurry or low-resolution.',
      });
    }

    if (parsed.error) {
      return res.status(422).json({ error: parsed.error });
    }

    res.json(parsed);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error while processing receipt.' });
  }
});

// multer error handler
app.use((err, req, res, next) => {
  if (err.message?.includes('Only JPEG')) {
    return res.status(400).json({ error: err.message });
  }
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(400).json({ error: 'Image too large. Max size is 10MB.' });
  }
  next(err);
});

app.listen(PORT, () => {
  console.log(`Receipt scanner running on http://localhost:${PORT}`);
});
