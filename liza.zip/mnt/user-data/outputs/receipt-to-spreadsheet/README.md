# 🧾 Receipt → Spreadsheet

Upload a photo of a receipt, get back a clean table of vendor, date, line items, quantities, prices, tax, and total. One-click CSV export.

## Running it

```bash
cp .env.example .env
# Add your ANTHROPIC_API_KEY to .env
npm install
npm start
# Open http://localhost:3000
```

On Replit: add `ANTHROPIC_API_KEY` to Secrets, hit Run.

## What it does

1. User uploads a receipt image (JPEG/PNG/WEBP, drag-and-drop supported)
2. Image is sent to Claude's vision model as base64 with a strict JSON schema prompt
3. Response is parsed and rendered as a styled table with subtotal/tax/total breakdown
4. CSV download generates a properly quoted file named after the vendor and date

Handles:
- Non-receipt images → shows a clear "not a receipt" message
- Blurry/unreadable images → explains the problem instead of crashing
- Missing fields (e.g. no date on the receipt) → shows null gracefully
- Oversized files (>10MB) → blocked before hitting the API

## The prompt I used

The key decision was forcing JSON-only output with an explicit schema, rather than asking Claude to "describe the receipt." Free-form output is unparseable at scale. I specify every field type (numbers not strings for monetary values) because early drafts had Claude returning `"12.99"` instead of `12.99`, which broke the table rendering.

I also had to add `"If the image is not a receipt, return { error: '...' }"` because without it, Claude would try to extract "items" from a photo of a dog.

## What I'd add with more time

- Multi-page receipts (send multiple images in one API call)
- A "correct this item" inline edit before downloading CSV
- Confidence score — if the total doesn't match sum(items) + tax, flag it
- Support for PDF receipts via pdf-parse before sending to vision model
