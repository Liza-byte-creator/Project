const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '50kb' }));
app.use(express.static('public'));

app.post('/api/remix', async (req, res) => {
  const { recipe, constraint, unit } = req.body;

  if (!recipe || recipe.trim().length < 20) {
    return res.status(400).json({ error: 'Recipe is too short. Paste the full recipe text.' });
  }
  if (!constraint || constraint.trim().length < 2) {
    return res.status(400).json({ error: 'Add a constraint (e.g. "make it vegan", "halve it").' });
  }

  const unitNote = unit === 'metric'
    ? ' Use metric units (grams, ml, Celsius) throughout.'
    : ' Use imperial units (cups, oz, Fahrenheit) throughout.';

  const prompt = `You are a recipe editor. Adapt the recipe below to meet a constraint, then explain what changed.

CONSTRAINT: ${constraint.trim()}${unitNote}

RECIPE:
${recipe.trim()}

Respond ONLY with a JSON object with this exact structure, no extra text:
{
  "adapted_recipe": "the full adapted recipe as plain text with ingredients and instructions",
  "changes": ["short bullet: what changed and why", "another change", ...],
  "impossible": false,
  "impossible_reason": ""
}

Rules:
- If the recipe CAN be adapted: fill adapted_recipe and changes, set impossible to false
- If it genuinely CANNOT be adapted (e.g. "make beef stew vegan" where the core ingredient is meat): set impossible to true, write a helpful impossible_reason explaining the conflict and suggesting the closest alternative that WOULD work, leave adapted_recipe empty
- changes should be 2-8 bullet items, concise (under 15 words each)
- Preserve the original recipe's structure — if it had sections (marinade, sauce, etc.), keep them
- No markdown in adapted_recipe, no asterisks, just clean text
- No preamble, no sign-off, just the JSON`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-opus-4-5',
        max_tokens: 1500,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    if (!response.ok) {
      return res.status(502).json({ error: 'AI failed to adapt the recipe. Try again.' });
    }

    const data = await response.json();
    const raw = data.content[0].text.trim()
      .replace(/^```(?:json)?\n?/, '')
      .replace(/\n?```$/, '');

    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return res.status(422).json({ error: 'Could not parse AI response. Try again.' });
    }

    res.json(parsed);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error.' });
  }
});

app.listen(PORT, () => {
  console.log(`Recipe Remixer running on http://localhost:${PORT}`);
});
