# 🍴 Recipe Remixer

Paste any recipe, add a constraint (vegan, halve it, 30 minutes, kid-friendly), get back an adapted recipe with a summary of what changed. Imperial ↔ metric toggle re-runs the adaptation in the new unit system.

## Running it

```bash
cp .env.example .env
# Add ANTHROPIC_API_KEY to .env
npm install
npm start
# Open http://localhost:3000
```

On Replit: add `ANTHROPIC_API_KEY` to Secrets.

## What it does

1. Paste any recipe (ingredients + instructions)
2. Type a constraint or pick from the presets
3. Claude adapts the recipe, preserves the structure, explains every substitution
4. If the constraint is genuinely impossible (e.g. vegan beef stew where beef is the whole point), it explains why and suggests the nearest alternative — no crash, no empty output

Imperial ↔ metric toggle re-sends the same recipe with a unit instruction appended, so you get a fresh adaptation in the right system.

## The prompt approach

The key design decision was returning structured JSON instead of prose. Early version asked Claude to "write the adapted recipe and then explain changes" — the output was good but hard to parse into the two-column layout.

Switching to JSON with `adapted_recipe` and `changes` let me render them as separate panels. This also made the impossible-recipe case clean: `"impossible": true` with an explanation is a real API response, not an error — it means the app worked correctly.

The `impossible` flag handles the edge case the spec calls out. "Make a steak vegan" returns:
```json
{
  "impossible": true,
  "impossible_reason": "Steak is beef; replacing it entirely would make this a different dish. Try a mushroom or lentil-based recipe with the same seasoning profile instead."
}
```

### What I tried first

First attempt used a simple "if you can't adapt it, say so" instruction. Claude would say so — but in a long paragraph mixed into the recipe text. The `impossible` boolean makes the frontend handle it cleanly.

## What I'd add with more time

- Save adapted recipes to browser localStorage with a little library view
- "Nutritional delta" — rough comparison of the before/after macros
- Allow pasting a URL to a recipe page instead of the raw text (fetch + strip HTML)
- The unit toggle currently re-runs the full API call; with more time I'd cache the base result and only convert units client-side for simple cases
